class S104Def:
    dataset_names= ('waterLevelHeight', 'waterLevelTrend')
    dataset_types= (np.float64, np.int8)
    product_id= 'WaterLevel'
    file_type= '104'
