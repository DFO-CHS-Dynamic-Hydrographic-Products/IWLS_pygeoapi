# # Standard library imports
# import requests, json, datetime, os, uuid

# # Packages imports
# from zipfile import ZipFile
# import pandas as pd
# import requests_cache
# import dateutil.parser
# from pygeoapi.provider.base import BaseProvider

# # Local imports
# from provider_iwls.iwls import IwlsApiConnector

# class IwlsApiConnector(BaseProvider):
#     """
#     Provider abstract base class for iwls data
#     Used as parent by ProviderIwlsWaterLevels and ProviderIwlsCurrents
#     """
#     def __init__(self, provider_def):
#         """Inherit from parent class"""
#         super().__init__(provider_def)
#         self.info = self.get_summary_info()

#     def get_summary_info(self):
#         """
#         Get summary information for all stations.Runs on class instantiation.
#         Output is used to match station codes and names to unique IWLS database id.

#         :returns: Pandas dataframe containing summary information for all stations
#         """

#         # Set up requests_cache session
#         s_summary_info = requests_cache.CachedSession('http_cache', backend='filesystem',expire_after=86400)

#         # Request data from cache or trought get request
#         url = 'https://api-iwls.dfo-mpo.gc.ca/api/v1/stations/'
#         params = {}
#         r = s_summary_info.get(url=url, params=params)

#         logging.info(f'From cache: {r.from_cache}')
#         logging.info(f'Created: {r.created_at}')
#         logging.info(f'Expires: {r.expires}')

#         r.raise_for_status()
#         data_json = r.json()

#         return pd.DataFrame.from_dict(data_json)

#     def id_from_station_code(self, station_code):
#         """
#         Return unique id for a station from five digits identifier
#         :param sation_code: five digits station identifier (string)
#         :returns: unique IWLS database id (int)
#         """
#         iwls_id = self.info.loc[self.info.code==station_code].id.values[0]
#         return iwls_id

#     def id_from_station_name(self, station_name):
#         """
#         Return unique id for a station from exact official name
#         :param sation_name: Station exact official name (string)
#         :returns: unique IWLS database id (int)
#         """
#         iwls_id = self.info.loc[self.info.officialName==station_name].id.values[0]
#         return iwls_id

#     def station_name_from_id(self, iwls_id):
#         """
#         Return  station  exact official name from unique id
#         :param iwls_id:unique IWLS database id (string)
#         :returns: Station Name (string)
#         """
#         station_name = self.info.loc[self.info.id==iwls_id].officialName.values[0]
#         return station_name

#     def get_station_metadata(self, station_code, cache_result=True):
#         """
#         Return a json response from the IWLS API containing full metadata for a single station.

#         :param station_code: = five digit station identifier (string)
#         :cache_result: boolean, if true use requests_cache to cache results (bool)
#         :returns: Station Metadata (JSON)
#         """
#         station_id = self.id_from_station_code(station_code)
#         url = 'https://api-iwls.dfo-mpo.gc.ca/api/v1/stations/' + station_id + '/metadata'
#         params = {}

#         if cache_result == True:
#             s_stn_metadata = requests_cache.CachedSession('http_cache', backend='filesystem',expire_after=2629746)
#             r = s_stn_metadata.get(url=url, params=params)
#         else:
#             r = requests.get(url=url, params=params)
#         r.raise_for_status()
#         metadata_json = r.json()
#         return metadata_json

#     def _get_station_data(self, identifier: int, start_time: str,end_time: str):
#         """
#         Get the station data.

#         :param identifier: station ID (int)
#         :param  start_time: Start time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param  end_time: End time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)

#         :returns: GeoJSON feature
#         """

#         # Can only get 7 days of data per request, split data in multiple requests if needed
#         #(ToDo: had check to block large requests in ProviderIwls class)
#         start_time_dt = dateutil.parser.parse(start_time)
#         end_time_dt = dateutil.parser.parse(end_time)
#         date_list = [start_time_dt]
#         if (end_time_dt - start_time_dt) > datetime.timedelta(days=5):
#             date_list.append(start_time_dt + datetime.timedelta(days=5))
#             while (date_list[-1]  + datetime.timedelta(days=5)) < end_time_dt:
#                 date_list.append(date_list[-1] + datetime.timedelta(days=5))
#         date_list.append(end_time_dt)

#         # Create list of start time and end time pairs
#         time_ranges = []

#         for idx, i in enumerate(date_list[:-1]):
#             time_ranges.append([i,date_list[idx+1] - datetime.timedelta(seconds=1)])
#         time_ranges[-1][-1] = time_ranges[-1][-1] + datetime.timedelta(seconds=1)

#         #  Convert datetime object back to ISO 8601 format strings
#         time_ranges_strings = [[datetime.datetime.strftime(i,'%Y-%m-%dT%H:%M:%SZ',) for i in x] for x in time_ranges]

#         # Execute all get requests

#         # Get metadata
#         metadata = self.get_station_metadata(station_code)

#         station_id = self.id_from_station_code(station_code)
#         url = 'https://api-iwls.dfo-mpo.gc.ca/api/v1/stations/' + station_id + '/data'

#         return time_ranges_strings, metadata, url


#     def _get_timeseries_by_boundary(self, start_time: str, end_time: str, bbox: list,
#                                              limit: int, start_index: int):
#         """
#         Used by Query Method
#         :param  start_time: Start time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param  start_time: Start time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param bbox: bounding box [minx,miny,maxx,maxy] (list)
#         :param limit: number of records to return (default 10) (int)
#         :param start_index: starting record to return (default 0) (int)

#         :returns: lat/lon values in bounding box, list of stations, end index and unpopulated geojson
#         """
#         # use summary metadata info to find stations within request
#         within_lat = self.info['latitude'].between(bbox[1], bbox[3])
#         within_lon = self.info['longitude'].between(bbox[0], bbox[2])

#         stations_list_data = self.info[within_lat & within_lon]
#         stations_list = stations_list_data[start_index:end_index]

#         # Only Query stations up  from start index to limit
#         end_index = start_index + limit

#         timeseries_data = {"type": "featureCollection"}

#         return within_lat, within_lon, stations_list, end_index, timeseries_data


#     def get(self, identifier: int, **kwargs):
#         """
#         Get feature by id

#         :param identifier: feature id (int)
#         :returns: feature collection
#         """
#         result = None

#         # Establish connection to IWLS API
#         api = IwlsApiConnector()
#         # Only latest 24h of data available throught get method
#         now = datetime.datetime.now()
#         tomorrow = now + datetime.timedelta(days=1)
#         yesterday = now - datetime.timedelta(days=1)
#         end_time = tomorrow.strftime('%Y-%m-%dT%H:%M:%SZ')
#         start_time = yesterday.strftime('%Y-%m-%dT%H:%M:%SZ')

#         # Pass query to IWLS API and return result
#         return self._provider_get_station_data(identifier,start_time,end_time,api)

#     # def query(self, start_index=0, limit=10, result_type='results',
#     #           bbox=[], datetime_=None, properties=[], sortby=[],
#     #           select_properties=[], skip_geometry=False, q=None, **kwargs):

#     #     """
#     #     Query IWLS
#     #     :param start_index: starting record to return (default 0) (int)
#     #     :param limit: number of records to return (default 10) (int)
#     #     :param result_type: return results or hit limit (default results)
#     #     :param bbox: bounding box [minx,miny,maxx,maxy] (list)
#     #     :param datetime_: temporal (datestamp or extent) (string)
#     #     :param properties: list of tuples (name, value) (list)
#     #     :param sortby: list of dicts (property, order) (list)
#     #     :param select_properties: list of property names (list)
#     #     :param skip_geometry: bool of whether to skip geometry (default False) (bool)
#     #     :param q: full-text search term(s) (string)

#     #     :returns: dict of 0..n GeoJSON features
#     #     """
#     #     result  = None

#     #     if not bbox:
#     #        bbox = [-180,-90,180,90]

#     #     if not datetime_:
#     #         now = datetime.datetime.now()
#     #         yesterday = now - datetime.timedelta(days=1)
#     #         tomorrow = now + datetime.timedelta(days=1)
#     #         end_time = tomorrow.strftime('%Y-%m-%dT%H:%M:%SZ')
#     #         start_time = yesterday.strftime('%Y-%m-%dT%H:%M:%SZ')
#     #     else:
#     #         start_time = datetime_.split('/')[0]
#     #         end_time = datetime_.split('/')[1]

#     #     # Establish connection to IWLS API
#     #     api = IwlsApiConnector()

#     #     # Pass query to IWLS API
#     #     result = self._get_timeseries_by_boundary(start_time,end_time,bbox,limit,start_index,api)

#     #     return result

# class IwlsApiConnectorWaterLevels(IwlsApiConnector):
#     """
#     Provider class used to retrieve iwls SurfaceCurrents data.
#     """
#     def __init__(self, provider_def):
#         """Inherit from parent class"""

#         super().__init__(provider_def)

#     def _get_station_data(self, identifier: int, start_time: str,end_time: str):
#         """
#         Used by Get Method
#         :param identifier: station ID (int)
#         :param  start_time: Start time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param  end_time: End time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)

#         :returns: station GeoJSON feature
#         """
#         time_ranges_strings, metadata, url = super()._provider_get_station_data(identifier, start_time, end_time)

#         # Get Observations, Predictions, Forecasts and SPINE
#         wlo = self._get_timeseries(url,time_ranges_strings,'wlo')
#         wlp = self._get_timeseries(url,time_ranges_strings,'wlp')
#         wlf = self._get_timeseries(url,time_ranges_strings,'wlf')
#         spine = self._get_timeseries(url,time_ranges_strings,'wlf-spine')

#         # Build Geojson feature for station
#         station_geojson = {}
#         station_geojson['type'] = 'Feature'
#         station_geojson['id'] = metadata['code']
#         station_geojson["geometry"] = {
#             "type": "Point",
#             "coordinates":[metadata['longitude'],metadata['latitude']],
#             }
#         station_geojson['properties'] = {
#             'metadata':metadata,
#             'wlo':json.loads(wlo)['value'],
#             'wlp':json.loads(wlp)['value'],
#             'wlf':json.loads(wlf)['value'],
#             'spine':json.loads(spine)['value'],
#             }

#         return station_geojson

#     def _get_timeseries_by_boundary(self, start_time: str, end_time: str, bbox: list,
#                                              limit: int, start_index: int):
#         """
#         Used by Query Method
#         :param  start_time: Start time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param  start_time: Start time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param bbox: bounding box [minx,miny,maxx,maxy] (list)
#         :param limit: number of records to return (default 10) (int)
#         :param start_index: starting record to return (default 0) (int)
#         :param api: api connection to IWLS (IwlsApiConnector)

#         :returns: dict of 0..n GeoJSON features
#         """
#         within_lat, within_lon, stations_list, end_index, timeseries_data = super()._provider_get_timeseries_by_boundary(start_time, end_time,bbox, limit, start_index)

#         for stn in stations_list.code.iteritems():
#             feature = self.get_station_data(stn[1],start_time,end_time)
#             features.append(feature)
#         timeseries_data['features'] = features

#         with open('test.json', 'w', encoding='utf-8') as f:
#             json.dump(timeseries_data, f, ensure_ascii=False, indent=4)

#         return timeseries_data

# class IwlsApiConnectorCurrents(IwlsApiConnector):
#     """
#     Provider class used to retrieve iwls SurfaceCurrents data.
#     """
#     def __init__(self, provider_def):
#         """
#         Inherit from parent class
#         """
#         super().__init__(provider_def)


#     def _get_station_data(self, identifier: int, start_time: str,end_time: str):
#         """
#         Sends a request to retreive the station data.

#         :param identifier: station ID (int)
#         :param  start_time: Start time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param  end_time: End time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param api: api connection to IWLS (IwlsApiConnector)

#         :returns: GeoJSON feature (json)
#         """
#         time_ranges_strings, metadata, url = super()._provider_get_station_data(identifier, start_time, end_time)

#         #Get Surface Currents observations (speed and direction)
#         wcs = self._get_timeseries(url,time_ranges_strings,'wcs1')
#         wcd = self._get_timeseries(url,time_ranges_strings,'wcd1')
#         # Build Geojson feature for station
#         station_geojson = {}
#         station_geojson['type'] = 'Feature'
#         station_geojson['id'] = metadata['code']
#         station_geojson["geometry"] = {
#             "type": "Point",
#             "coordinates":[metadata['longitude'],metadata['latitude']],
#             }
#         station_geojson['properties'] = {
#             'metadata':metadata,
#             'wcs':json.loads(wcs)['value'],
#             'wcd':json.loads(wcd)['value'],
#             }

#         return station_geojson

#     def _get_timeseries_by_boundary(self, start_time: str, end_time: str, bbox: list,
#                                              limit: int, start_index: int):
#         """
#         Sends a request to retreive timeseries data in a specified bounding box.

#         :param  start_time: Start time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param  end_time: End time, ISO 8601 format UTC (e.g.: 2019-11-13T19:18:00Z) (string)
#         :param bbox: bounding box [minx,miny,maxx,maxy] (list)
#         :param limit: number of records to return (default 10) (int)
#         :param start_index: starting record to return (default 0) (int)
#         :param api: api connection to IWLS (IwlsApiConnector)

#         :returns: dict of 0..n GeoJSON features (json)
#         """
#         within_lat, within_lon, stations_list, end_index, timeseries_data = super()._provider_get_timeseries_by_boundary(start_time, end_time,bbox, limit, start_index)
#         stations_list = stations_list[stations_list['timeSeries'].astype(str).str.contains('wcs1')]

#         for stn in stations_list.code.iteritems():
#             feature = self.get_station_data(stn[1],start_time,end_time,'wcs')
#             features.append(feature)
#         timeseries_data['features'] = features
#         # with open('test.json', 'w', encoding='utf-8') as f:
#         #     json.dump(timeseries_data, f, ensure_ascii=False, indent=4)

#         return timeseries_data
